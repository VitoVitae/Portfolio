/**
 * \file Elimination_Version2.c
 * 
 * \brief
 * 
 * \author Paolo Toé
 * 
 * \version 1.0.0
 * 
 * \date 26/11/2023
 * 
 *  
 * 
*/

#include <stdlib.h>
#include <stdio.h>

#define N 3
#define TAILLE (N*N)

typedef struct {
int valeur;
bool candidats[TAILLE + 1];
int nbCandidats;
} tCase2;
typedef tCase2 tGrille[TAILLE][TAILLE];

void singletonNu(tGrille g);
void chargerGrille(tGrille g);

int main()
{

}

void singletonNu(tGrille g)
{
    for (int i = 0; i < TAILLE; i++)
    {
        for (int j = 0; j < TAILLE; j++)
        {
            if (g[i][j].nbCandidats==1)
            {
                for (int k = 0; k < TAILLE+1 ; k++)
                {
                    if (g[i][j].Candidats)
                    {
                        g[i][j].valeur=g[i][j].candidats[k];
                    }
                }
                
            }
        }
        
    }
    
}

/**
 * \fn void chargerGrille(tGrille g)
 * \brief Prend les donneées d'un fichier .sud et affecte chaque chiffre à la grille vide en paramètre
 * \param g : grille de sudoku vide
 * 
 * Cette procédure permet de charger en mémoire une grille de sudoku existante à partir d’un fichier dont le nom est lu au clavier.
*/

void chargerGrille(tGrille g)
{
    char nomFichier[30];
    FILE * f;
    printf("Nom du fichier ? ");
    scanf("%s", nomFichier);
    f = fopen(nomFichier, "rb");
    if (f==NULL)
    {
        printf("\n ERREUR sur le fichier %s\n", nomFichier);
    } 
    else 
    {
        fread(g, sizeof(int), TAILLE*TAILLE, f);
    }
        fclose(f);
}
